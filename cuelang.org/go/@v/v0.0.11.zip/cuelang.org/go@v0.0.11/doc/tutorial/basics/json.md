[TOC](Readme.md) _Prev_ [Next](fieldname.md)


# JSON sugar and other Goodness

CUE is an extension of JSON.
This improves familiarity and makes it easy to get going quickly.

In its simplest use case, CUE can substitute for a more pleasant way to write
JSON.
