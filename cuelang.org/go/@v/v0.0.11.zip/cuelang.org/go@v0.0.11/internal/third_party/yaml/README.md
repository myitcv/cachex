# YAML reader for CUE

This yaml parser is a heavily modified version of Canonical's go-yaml parser,
which in turn is a port of the [libyaml](http://pyyaml.org/wiki/LibYAML) parser.


License
-------

The yaml package is licensed under the Apache License 2.0. Please see the LICENSE file for details.

