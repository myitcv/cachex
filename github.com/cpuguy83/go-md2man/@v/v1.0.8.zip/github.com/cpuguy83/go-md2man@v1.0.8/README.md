go-md2man
=========

** Work in Progress **
This still needs a lot of help to be complete, or even usable!

Uses blackfriday to process markdown into man pages.

### Usage

./md2man -in /path/to/markdownfile.md -out /manfile/output/path

### How to contribute

We use [dep](https://github.com/golang/dep/) for vendoring Go packages.
See dep documentation for how to update.

### TODO

- Needs oh so much testing love
- Look into blackfriday's 2.0 API
