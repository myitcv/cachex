# js/xhr

Package xhr provides GopherJS bindings for the XMLHttpRequest API.

## Install

    go get honnef.co/go/js/xhr

## Documentation

For documentation, see http://godoc.org/honnef.co/go/js/xhr
