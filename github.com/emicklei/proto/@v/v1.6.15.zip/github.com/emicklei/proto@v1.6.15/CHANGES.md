## v1.6.13

- fixes breaking change introduced by v1.6.11 w.r.t Literal

## < v1.6.12

 - see git log