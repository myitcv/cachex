// +build js

package atomic_test

import "testing"

func TestHammerStoreLoad(t *testing.T) {
	t.Skip("use of unsafe")
}
