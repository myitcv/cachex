// +build !go1.11
// +build go1.10

package compiler

const ___GOPHERJS_REQUIRES_GO_VERSION_1_10___ = true

// Version is the GopherJS compiler version string.
const Version = "1.10-4"
