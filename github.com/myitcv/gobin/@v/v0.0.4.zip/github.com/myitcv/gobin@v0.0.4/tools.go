// +build tools

package tools

import (
	_ "github.com/rogpeppe/go-internal/cmd/txtar-addmod"
	_ "myitcv.io/cmd/egrunner"
	_ "myitcv.io/cmd/githubcli"
	_ "myitcv.io/cmd/mdreplace"
)
