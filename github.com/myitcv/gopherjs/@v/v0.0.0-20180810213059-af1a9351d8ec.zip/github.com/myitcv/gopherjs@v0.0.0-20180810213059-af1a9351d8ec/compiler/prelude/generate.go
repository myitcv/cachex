package prelude

//go:generate go run formatpreludejs.go
//go:generate go run genprelude.go
