// +build js

package cpu

const CacheLineSize = 0
