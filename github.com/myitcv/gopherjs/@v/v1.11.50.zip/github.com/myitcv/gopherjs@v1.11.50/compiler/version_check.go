// +build go1.11
// +build !go1.12

package compiler

const ___GOPHERJS_REQUIRES_GO_VERSION_1_11___ = true

// Version is the GopherJS compiler version string.
const Version = "1.11-2"
