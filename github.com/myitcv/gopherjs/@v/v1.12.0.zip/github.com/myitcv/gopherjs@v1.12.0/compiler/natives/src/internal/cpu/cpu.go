// +build js

package cpu

const CacheLineSize = 0
const CacheLinePadSize = 0
