// +build js

package sys

type Uintreg uint32

const GoarchArm64 = 0
