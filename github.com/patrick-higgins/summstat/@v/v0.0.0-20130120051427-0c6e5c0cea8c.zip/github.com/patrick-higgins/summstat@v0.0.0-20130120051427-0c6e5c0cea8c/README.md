summstat
========

Incremental summary statistics for the Go programming language