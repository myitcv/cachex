// +build !linux,!darwin

package sftp

const sftpServer = "/usr/bin/false" // unsupported
