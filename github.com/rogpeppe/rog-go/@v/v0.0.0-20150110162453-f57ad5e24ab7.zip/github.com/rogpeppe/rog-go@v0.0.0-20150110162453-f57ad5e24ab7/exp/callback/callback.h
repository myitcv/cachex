void callback(void (*f)(void*), void*arg);
void runCallbacks(void);
void callbackInit(void);
void *callbackFunc(void);
