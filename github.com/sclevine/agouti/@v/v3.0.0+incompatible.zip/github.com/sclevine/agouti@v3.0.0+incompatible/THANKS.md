Many thanks to:

 * Zach Gershman and Pete Alfvin for helping me get this project off the ground.
 * Onsi Fakhouri for answering endless questions and contributing.
 * Abby Sturges for the wonderful logo on agouti.org!
