// Package matchers provides a set of Gomega-compatible matchers for use
// with the agouti package.
package matchers
