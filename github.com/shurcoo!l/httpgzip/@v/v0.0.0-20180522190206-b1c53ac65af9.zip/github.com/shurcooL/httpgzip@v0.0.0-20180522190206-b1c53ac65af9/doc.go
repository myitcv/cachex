// Package httpgzip provides net/http-like primitives
// that use gzip compression when serving HTTP requests.
package httpgzip
