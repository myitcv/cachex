// +build !go1.8

package ssa

import "go/types"

var structTypesIdentical = types.Identical
