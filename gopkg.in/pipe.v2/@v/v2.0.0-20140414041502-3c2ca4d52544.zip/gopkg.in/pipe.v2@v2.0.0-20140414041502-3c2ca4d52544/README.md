Installation and usage
----------------------

See [gopkg.in/pipe.v2](https://gopkg.in/pipe.v2) for documentation and usage details.
