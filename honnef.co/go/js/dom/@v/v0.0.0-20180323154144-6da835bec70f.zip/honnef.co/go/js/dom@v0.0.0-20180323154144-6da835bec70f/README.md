# js/dom

Package dom provides GopherJS bindings for the JavaScript DOM APIs.

## Install

    go get honnef.co/go/js/dom

## Documentation

For documentation, see http://godoc.org/honnef.co/go/js/dom
