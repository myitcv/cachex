# js/util

Package util provides some helpers for working with GopherJS.

## Install

    go get honnef.co/go/js/util
